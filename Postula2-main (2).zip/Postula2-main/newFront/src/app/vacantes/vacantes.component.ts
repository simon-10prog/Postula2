import { Component } from '@angular/core';

@Component({
  selector: 'app-vacantes',
  standalone: true,
  imports: [],
  templateUrl: './vacantes.component.html',
  styleUrl: './vacantes.component.css'
})
export class VacantesComponent {

}

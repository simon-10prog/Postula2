package co.edu.uco.postumot.postulant.bussineslogic.usecase.postulante.impl;

import java.util.UUID;

import co.edu.uco.postumot.postulant.bussineslogic.usecase.postulante.DeletePosulante;

public final class DeletePosulanteImpl implements DeletePosulante{

	@Override
	public void execute(UUID data) {
		// TODO Auto-generated method stub
		
	}

}

package co.edu.uco.postumot.common.data.dao.enums;

public enum DAOSource {
	SQLSERVER, MYSQL, ORACLE, POSTGRESQL, XYZ
}

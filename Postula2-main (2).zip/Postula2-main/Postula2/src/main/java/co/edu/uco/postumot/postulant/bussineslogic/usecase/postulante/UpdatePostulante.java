package co.edu.uco.postumot.postulant.bussineslogic.usecase.postulante;

import co.edu.uco.postumot.common.bussineslogic.usecase.UseWithoutReturn;
import co.edu.uco.postumot.postulant.domain.PostulanteDomain;

public interface UpdatePostulante extends UseWithoutReturn<PostulanteDomain>{

}

package co.edu.uco.postumot.postulant.data.dao.crud;

public interface CreateDAO<T> {

	void create(T data);

}

package co.edu.uco.postumot.controller;

import co.edu.uco.postumot.catalog.Message;
import co.edu.uco.postumot.catalog.MessageCatalog;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/messages/api/v1/messages")
public class MessageController {

    @GetMapping("/{key}")
    public ResponseEntity<Message> getMessage(@PathVariable String key) {
        var message = MessageCatalog.getMessage(key);
        return new ResponseEntity<>(message, (message == null) ? HttpStatus.BAD_REQUEST : HttpStatus.OK);
    }

    @PutMapping("/{key}")
    public ResponseEntity<Message> modifyMessage(@PathVariable String key, @RequestBody Message value) {
        value.setKey(key);
        MessageCatalog.synchronizeMessage(value);
        return new ResponseEntity<>(value, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Message> createMessage(@RequestBody Message value) {
        if (value == null || value.getKey() == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        MessageCatalog.synchronizeMessage(value);
        return new ResponseEntity<>(value, HttpStatus.CREATED);
    }

    @DeleteMapping("/{key}")
    public ResponseEntity<Void> removeMessage(@PathVariable String key) {
        MessageCatalog.removeMessage(key);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @GetMapping
    public ResponseEntity<Map<String, Message>> getAllMessages() {
        return new ResponseEntity<>(MessageCatalog.getAllMessages(), HttpStatus.OK);
    }
}
package co.edu.uco.postumot.notification.init;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
@Order(0)
public class DbInitializer implements ApplicationRunner {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        // Ensure the fcm_tokens table exists (idempotent)
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS fcm_tokens ("
                + "id BIGSERIAL PRIMARY KEY,"
                + "token VARCHAR(1024) NOT NULL UNIQUE,"
                + "created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL"
                + ")");
    }
}

package co.edu.uco.postumot.postulant.bussineslogic.usecase.postulante;

import java.util.UUID;

import co.edu.uco.postumot.common.bussineslogic.usecase.UseWithoutReturn;

public interface DeletePosulante extends UseWithoutReturn<UUID> {

}

package co.edu.uco.postumot.notification.repository;

// Repository disabled — replaced with inert placeholder to avoid Spring Data JPA automatic repository creation
class FcmTokenRepositoryDisabled {
    // This class intentionally left blank to avoid repository bean creation.
}
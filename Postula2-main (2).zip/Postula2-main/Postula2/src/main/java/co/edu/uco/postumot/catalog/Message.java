package co.edu.uco.postumot.catalog;

public class Message {
    private String key;
    private String text;
    private Level level; // INFO, WARNING, ERROR

    public Message() {}

    public Message(String key, String text, Level level) {
        setKey(key);
        setText(text);
        setLevel(level);
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }
}
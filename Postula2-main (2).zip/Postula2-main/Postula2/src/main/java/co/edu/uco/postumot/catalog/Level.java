package co.edu.uco.postumot.catalog;

public enum Level {
    INFO,
    WARNING,
    ERROR
}

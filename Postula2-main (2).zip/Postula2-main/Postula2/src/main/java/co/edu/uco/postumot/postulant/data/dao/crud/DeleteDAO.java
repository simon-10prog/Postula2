package co.edu.uco.postumot.postulant.data.dao.crud;

public interface DeleteDAO<T> {

	void delete(T data);

}

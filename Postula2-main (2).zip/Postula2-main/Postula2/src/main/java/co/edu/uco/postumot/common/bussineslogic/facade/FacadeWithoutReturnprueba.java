package co.edu.uco.postumot.common.bussineslogic.facade;

public interface FacadeWithoutReturnprueba <T> {
	void execute(T data);
}

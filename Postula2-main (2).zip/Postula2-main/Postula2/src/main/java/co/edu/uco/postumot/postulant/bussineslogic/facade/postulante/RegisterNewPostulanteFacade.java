package co.edu.uco.postumot.postulant.bussineslogic.facade.postulante;

import co.edu.uco.postumot.postulant.bussineslogic.facade.FacadeWithoutReturn;
import co.edu.uco.postumot.postulant.dto.PostulanteDTO;

public interface RegisterNewPostulanteFacade extends FacadeWithoutReturn<PostulanteDTO>{

}

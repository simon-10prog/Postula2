package co.edu.uco.postumot.postulant.bussineslogic.usecase.postulante.rule;

import co.edu.uco.postumot.common.bussineslogic.usecase.RuleWithOutFactory;

public interface PostulanteNameConsistencyIsValid extends RuleWithOutFactory<String>{

}

package co.edu.uco.postumot.notification.service;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FcmTokenService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Transactional
    public boolean saveIfNotExists(String token) {
        // Ensure table exists (idempotent)
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS fcm_tokens ("
                + "id BIGSERIAL PRIMARY KEY,"
                + "token VARCHAR(1024) NOT NULL UNIQUE,"
                + "created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL"
                + ")");

        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM fcm_tokens WHERE token = ?",
                new Object[] { token }, Integer.class);

        if (count != null && count > 0) {
            return false;
        }

        jdbcTemplate.update("INSERT INTO fcm_tokens (token, created_at) VALUES (?, ?)", token, Instant.now());
        return true;
    }
}
package co.edu.uco.postumot.notification.entity;

import java.time.Instant;

// POJO — not a JPA entity. Persistence is handled via JdbcTemplate.
public class FcmTokenEntity {

    private Long id;
    private String token;
    private Instant createdAt;

    public FcmTokenEntity() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
package co.edu.uco.postumot.postulant.bussineslogic.usecase.tipodocumento.rule;

import java.util.UUID;

import co.edu.uco.postumot.postulant.bussineslogic.usecase.RuleWithFactory;

public interface TipoDocumentoExists extends RuleWithFactory<UUID>{

}

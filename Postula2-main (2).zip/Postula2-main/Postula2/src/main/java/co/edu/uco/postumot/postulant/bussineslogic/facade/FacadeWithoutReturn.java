package co.edu.uco.postumot.postulant.bussineslogic.facade;

public interface FacadeWithoutReturn <T> {
	void execute(T data);
}

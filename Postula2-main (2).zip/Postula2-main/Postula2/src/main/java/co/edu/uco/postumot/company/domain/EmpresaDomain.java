package co.edu.uco.postumot.company.domain;

public class EmpresaDomain {

}

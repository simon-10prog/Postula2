package co.edu.uco.postumot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import co.edu.uco.postumot.service.FcmService;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.TopicManagementResponse;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/notifications/api/v1/notifications")
public class NotificationController {

    @Autowired
    private FcmService fcmService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostMapping("/send/token")
    public String sendNotificationToToken(@RequestParam String token,
                                          @RequestParam String title,
                                          @RequestParam String body) {
        try {
            return fcmService.sendNotificationToToken(token, title, body);
        } catch (FirebaseMessagingException e) {
            return "Error sending to token: " + e.getMessage();
        }
    }

    @PostMapping("/send/topic")
    public String sendNotificationToTopic(@RequestParam String topic,
                                          @RequestParam String title,
                                          @RequestParam String body) {
        try {
            return fcmService.sendNotificationToTopic(topic, title, body);
        } catch (FirebaseMessagingException e) {
            return "Error sending to topic: " + e.getMessage();
        }
    }

    @PostMapping("/topic/subscribe")
    public String subscribeToTopic(@RequestParam String topic, @RequestBody List<String> tokens) {
        try {
            TopicManagementResponse response = fcmService.subscribeToTopic(tokens, topic);
            return "Subscribed " + response.getSuccessCount() + " tokens; " +
                   response.getFailureCount() + " failed.";
        } catch (FirebaseMessagingException e) {
            return "Error subscribing to topic: " + e.getMessage();
        }
    }

    @PostMapping("/topic/unsubscribe")
    public String unsubscribeFromTopic(@RequestParam String topic, @RequestBody List<String> tokens) {
        try {
            TopicManagementResponse response = fcmService.unsubscribeFromTopic(tokens, topic);
            return "Unsubscribed " + response.getSuccessCount() + " tokens; " +
                   response.getFailureCount() + " failed.";
        } catch (FirebaseMessagingException e) {
            return "Error unsubscribing from topic: " + e.getMessage();
        }
    }

    // New endpoint to register/save FCM token using JdbcTemplate directly
    @PostMapping("/register-token")
    public String registerToken(@RequestParam String token) {
        try {
            // Ensure table exists
            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS fcm_tokens ("
                    + "id BIGSERIAL PRIMARY KEY,"
                    + "token VARCHAR(1024) NOT NULL UNIQUE,"
                    + "created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL"
                    + ")");

            Integer count = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM fcm_tokens WHERE token = ?",
                    new Object[] { token }, Integer.class);

            if (count != null && count > 0) {
                return "Token already registered";
            }

            jdbcTemplate.update("INSERT INTO fcm_tokens (token, created_at) VALUES (?, now())", token);
            return "Token registered";
        } catch (Exception e) {
            return "Error registering token: " + e.getMessage();
        }
    }
}
package co.edu.uco.postumot.common.bussineslogic.facade;

public interface FacadeWithReturnprueba <T,R> {
	R execute(T data);
	
}

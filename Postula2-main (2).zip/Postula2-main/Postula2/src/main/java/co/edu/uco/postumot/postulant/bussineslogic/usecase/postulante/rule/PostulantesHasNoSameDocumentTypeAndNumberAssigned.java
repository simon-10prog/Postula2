package co.edu.uco.postumot.postulant.bussineslogic.usecase.postulante.rule;

import co.edu.uco.postumot.postulant.bussineslogic.usecase.RuleWithFactory;
import co.edu.uco.postumot.postulant.domain.PostulanteDomain;

public interface PostulantesHasNoSameDocumentTypeAndNumberAssigned extends RuleWithFactory<PostulanteDomain>{

}

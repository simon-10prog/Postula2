package co.edu.uco.postumot.controller;

import co.edu.uco.postumot.catalog.Parameter;
import co.edu.uco.postumot.catalog.ParameterCatalog;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/parameters/api/v1/parameters")
public class ParameterController {

    @GetMapping("/{key}")
    public ResponseEntity<Parameter> getParameter(@PathVariable String key) {
        var value = ParameterCatalog.getParameterValue(key);
        return new ResponseEntity<>(value, (value == null) ? HttpStatus.BAD_REQUEST : HttpStatus.OK);
    }

    @PutMapping("/{key}")
    public ResponseEntity<Parameter> modifyParameter(@PathVariable String key, @RequestBody Parameter value) {
        value.setKey(key);
        ParameterCatalog.synchronizeParameter(value);
        return new ResponseEntity<>(value, HttpStatus.OK);
    }
    
    // Nota de "jacojarajara" - ¿Sera que estos se van a necesitar? Mi unica preocupacion seria que alguien 
    //							acceda a este api y deje a cualquier persona agregar/eliminar parametros.
    
    @PostMapping
    public ResponseEntity<Parameter> createParameter(@RequestBody Parameter value) {
        if (value == null || value.getKey() == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        ParameterCatalog.synchronizeParameter(value);
        return new ResponseEntity<>(value, HttpStatus.CREATED);
    }

    @DeleteMapping("/{key}")
    public ResponseEntity<Void> removeParameter(@PathVariable String key) {
        ParameterCatalog.removeParameter(key);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping
    public ResponseEntity<Map<String, Parameter>> getAllParameters() {
        return new ResponseEntity<>(ParameterCatalog.getAllParameters(), HttpStatus.OK);
    }
}
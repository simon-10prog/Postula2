package co.edu.uco.postumot.common.bussineslogic.usecase;

public interface UseWithoutReturn <D>{
	void execute(D data);
}

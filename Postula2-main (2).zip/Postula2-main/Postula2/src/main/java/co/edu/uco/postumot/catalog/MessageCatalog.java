package co.edu.uco.postumot.catalog;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public final class MessageCatalog {
    private static Map<String, Message> messages = new HashMap<>();

    private MessageCatalog() {}

    static {
        messages.put("DefaultMaxDateWarning", new Message("DefaultMaxDateWarning", "Default maximum date is 31/12/2500", Level.WARNING));
        messages.put("OperationSuccess", new Message("OperationSuccess", "The operation completed successfully.", Level.INFO));
        messages.put("OperationFailed", new Message("OperationFailed", "The operation failed. Please contact support.", Level.ERROR));
        // TODO: Agregar mas mensajes.
    }
    
    /*
		Resource bundle name: "messages" — the code loads messages from files named messages.properties, messages_en.properties, messages_es.properties, etc., located on the classpath (src/main/resources).
		* Lookup logic: when getMessage(key, locale) is called the catalog: 
			1) finds the stored Message entry (contains default text and level)
			2) attempts to load the localized text from the messages resource bundle
			3) if found, returns a new Message with the localized text and the stored level; otherwise returns the stored text.
		* The API and controllers keep returning Message objects (with Level enum for level).
		
		How to add message files (example)
		* Place properties on classpath, e.g.: src/main/resources/messages.properties
		* Example entries (plain lines): 
			DefaultMaxDateWarning=Default maximum date is 31/12/2500 
			OperationSuccess=The operation completed successfully. 
			OperationFailed=The operation failed. Please contact support.
		* For Spanish localization: src/main/resources/messages_es.properties 
			DefaultMaxDateWarning=La fecha máxima predeterminada es 31/12/2500 
			OperationSuccess=La operación se completó correctamente. 
			OperationFailed=La operación falló. Por favor contacte al soporte.
    */

    public static Message getMessage(String key) {
        return getMessage(key, Locale.getDefault());
    }

    public static Message getMessage(String key, Locale locale) {
        var stored = messages.get(key);
        if (stored == null) {
            return null;
        }

        String text;
        try {
            ResourceBundle bundle = ResourceBundle.getBundle("messages", locale);
            text = bundle.getString(key);
        } catch (MissingResourceException ex) {
            text = stored.getText();
        }

        return new Message(key, text, stored.getLevel());
    }

    public static void synchronizeMessage(Message message) {
        if (message == null || message.getKey() == null) {
            return;
        }
        messages.put(message.getKey(), message);
    }

    public static void removeMessage(String key) {
        messages.remove(key);
    }

    public static Map<String, Message> getAllMessages(Locale locale) {
        Map<String, Message> result = new HashMap<>();
        for (var entry : messages.entrySet()) {
            result.put(entry.getKey(), getMessage(entry.getKey(), locale));
        }
        return result;
    }

    public static Map<String, Message> getAllMessages() {
        return getAllMessages(Locale.getDefault());
    }
}
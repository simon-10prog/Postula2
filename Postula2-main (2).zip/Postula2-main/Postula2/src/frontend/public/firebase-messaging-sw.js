importScripts('https://www.gstatic.com/firebasejs/9.22.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.22.2/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyB2vbsS8EkvaFWpcgk53Kn0gVkRH746IVQ",
  authDomain: "postula2-e7b75.firebaseapp.com",
  projectId: "postula2-e7b75",
  storageBucket: "postula2-e7b75.firebasestorage.app",
  messagingSenderId: "59337498669",
  appId: "1:59337498669:web:c993aa5f40a65b9d64d8a4",
  measurementId: "G-J3BY06NDDJ"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  const notification = payload.notification || {};
  const title = notification.title || 'Background Message Title';
  const options = {
    body: notification.body || 'Background Message body.',
    // Add icon, data, etc. if needed
  };
  self.registration.showNotification(title, options);
});

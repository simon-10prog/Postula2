import React, { useState, useEffect } from 'react';
import './styles.css';

// --- Added Firebase imports ---
import { initializeApp } from 'firebase/app';
import { getMessaging, getToken, onMessage } from 'firebase/messaging';

// --- Move Firebase config and VAPID key to module scope ---
const firebaseConfig = 	{
	  apiKey: "AIzaSyB2vbsS8EkvaFWpcgk53Kn0gVkRH746IVQ",
	  authDomain: "postula2-e7b75.firebaseapp.com",
	  projectId: "postula2-e7b75",
	  storageBucket: "postula2-e7b75.firebasestorage.app",
	  messagingSenderId: "59337498669",
	  appId: "1:59337498669:web:c993aa5f40a65b9d64d8a4",
	  measurementId: "G-J3BY06NDDJ"
	};
const publicVapidKey = 'BOowfL1QCx85toqfGr91gdm4zy7BUIA464vccTFsAG_g8r2k-ImMZ0Tux_A3GQj4SKmjBrHdj4IZiYEOfvrHy5k';

// Add backend base URL including the context-path configured in application.properties
const BACKEND_BASE = 'http://localhost:8080/postumot';

function FormularioPostulante() {
    const [formData, setFormData] = useState({
        documento: '',
        firstName: '',
        secondName: '',
        lastName: '',
        lastSecondName: '',
        phone: '',
        email: '',
        sex: 'Femenino'  // Definir un valor predeterminado para "sex"
    });

    // --- FCM token state ---
    const [fcmToken, setFcmToken] = useState(null);

    useEffect(() => {
        // Initialize Firebase app and register service worker, then get token
        try {
            const app = initializeApp(firebaseConfig);
            if ('serviceWorker' in navigator) {
                navigator.serviceWorker.register('/firebase-messaging-sw.js')
                    .then((registration) => {
                        const messaging = getMessaging(app);

                        // Request notification permission
                        Notification.requestPermission().then(permission => {
                            if (permission !== 'granted') {
                                console.warn('Notification permission not granted.');
                                return;
                            }

                            // Get token
                            getToken(messaging, { vapidKey: publicVapidKey, serviceWorkerRegistration: registration })
                                .then((currentToken) => {
                                    if (currentToken) {
                                        setFcmToken(currentToken);

                                        // Optionally immediately inform backend about the token
                                        fetch(`${BACKEND_BASE}/notifications/api/v1/notifications/register-token?token=${encodeURIComponent(currentToken)}`, {
                                            method: 'POST'
                                        }).then(() => {
                                            console.log('Registered token on backend');
                                        }).catch(err => console.error('Error registering token on backend', err));
                                    } else {
                                        console.log('No registration token available. Request permission to generate one.');
                                    }
                                })
                                .catch((err) => {
                                    console.error('An error occurred while retrieving token. ', err);
                                });
                        });

                        // Optional: handle messages while app is in foreground
                        onMessage(messaging, (payload) => {
                            console.log('Message received. ', payload);
                        });
                    })
                    .catch(err => console.error('Service worker registration failed: ', err));
            } else {
                console.warn('Service workers are not supported in this browser.');
            }
        } catch (e) {
            console.error('Firebase init error', e);
        }
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        // Crear los datos a enviar
        const data = {
            documento: formData.documento,
            firstName: formData.firstName,
            secondName: formData.secondName,
            lastName: formData.lastName,
            lastSecondName: formData.lastSecondName,
            phone: formData.phone,
            email: formData.email,
            sex: formData.sex,
            tipodocumento_id: "00000000-0000-0000-0000-000000000000",  // Valor constante
            city_id: "00000000-0000-0000-0000-000000000000"  // Valor constante
        };

        // Hacer la solicitud POST para crear postulante
        fetch(`${BACKEND_BASE}/api/v1/postulante/create`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);  // Log de éxito

                // Optionally send a notification using the token the backend expects
                if (fcmToken) {
                    // Register token for server-side use; server will send notifications when needed
                    fetch(`${BACKEND_BASE}/notifications/api/v1/notifications/register-token?token=${encodeURIComponent(fcmToken)}`, {
                        method: 'POST'
                    })
                    .then(res => res.text())
                    .then(txt => console.log('Register token response:', txt))
                    .catch(err => console.error('Error registering token', err));
                } else {
                    console.log('No FCM token available to send notification.');
                }
            })
            .catch((error) => {
                console.error('Error:', error);  // Log de error
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            <div id="webcrumbs">
                <div className='w-[500px] bg-white rounded-lg shadow-lg p-8'>
                    <h1 className='text-2xl font-title mb-6'>Ingreso de Formularios</h1>
                    <div className='space-y-4'>
                        <div>
                            <label htmlFor='documento' className='block'>Número de Documento</label>
                            <input
                                type='text'
                                id='documento'
                                name='documento'
                                className='w-full p-2 border rounded-md'
                                value={formData.documento || ''}
                                onChange={handleChange}
                                placeholder='Ingrese Documento'
                                required
                                pattern='\d{8,10}'
                            />
                        </div>

                        <div>
                            <label htmlFor='firstName' className='block'>Primer Nombre</label>
                            <input
                                type='text'
                                id='firstName'
                                name='firstName'
                                className='w-full p-2 border rounded-md'
                                value={formData.firstName || ''}
                                onChange={handleChange}
                                placeholder='Ingrese Primer Nombre'
                                required
                                pattern='[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+'
                                minLength="1"
                                maxLength="60"
                            />
                        </div>

                        <div>
                            <label htmlFor='secondName' className='block'>Segundo Nombre</label>
                            <input
                                type='text'
                                id='secondName'
                                name='secondName'
                                className='w-full p-2 border rounded-md'
                                value={formData.secondName || ''}
                                onChange={handleChange}
                                placeholder='Ingrese Segundo Nombre'
                                pattern='[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+'
                            />
                        </div>

                        <div>
                            <label htmlFor='lastName' className='block'>Primer Apellido</label>
                            <input
                                type='text'
                                id='lastName'
                                name='lastName'
                                className='w-full p-2 border rounded-md'
                                value={formData.lastName || ''}
                                onChange={handleChange}
                                placeholder='Ingrese Primer Apellido'
                                required
                                pattern='[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+'
                                minLength="1"
                                maxLength="60"
                            />
                        </div>

                        <div>
                            <label htmlFor='lastSecondName' className='block'>Segundo Apellido</label>
                            <input
                                type='text'
                                id='lastSecondName'
                                name='lastSecondName'
                                className='w-full p-2 border rounded-md'
                                value={formData.lastSecondName || ''}
                                onChange={handleChange}
                                placeholder='Ingrese Segundo Apellido'
                                pattern='[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+'
                                required
                                minLength="1"
                                maxLength="60"
                            />
                        </div>

                        <div>
                            <label htmlFor='phone' className='block'>Celular</label>
                            <input
                                type='tel'
                                id='phone'
                                name='phone'
                                className='w-full p-2 border rounded-md'
                                value={formData.phone || ''}
                                onChange={handleChange}
                                placeholder='Ingrese Celular'
                                required
                                pattern='\d{10}'
                            />
                        </div>

                        <div>
                            <label htmlFor='email' className='block'>Correo Electrónico</label>
                            <input
                                type='email'
                                id='email'
                                name='email'
                                className='w-full p-2 border rounded-md'
                                value={formData.email || ''}
                                onChange={handleChange}
                                placeholder='Ingrese Correo Electrónico'
                                required
                                minLength="15"
                                maxLength="50"
                            />
                        </div>

                        <div>
                            <label htmlFor='sex' className='block'>Sexo</label>
                            <select
                                id='sex'
                                name='sex'
                                className='w-full p-2 border rounded-md'
                                value={formData.sex || 'Femenino'}
                                onChange={handleChange}
                            >
                                <option value='Femenino'>Femenino</option>
                                <option value='Masculino'>Masculino</option>
                            </select>
                        </div>

                        <button type='submit' className='bg-primary-500 text-white w-full py-2 rounded-full'>
                            Enviar
                        </button>

                        {/* Show token for debugging */}
                        {fcmToken && (
                            <div className='mt-2 text-sm break-all'>FCM token: {fcmToken}</div>
                        )}
                    </div>
                </div>
            </div>
        </form>
    );
}

export default FormularioPostulante;
import './App.css';
import React from 'react';
import FormularioPostulante from './components/FormularioPostulante'; // Importa el componente



function App() {
  return (
    <div className="App">
      <FormularioPostulante /> {/* Aquí lo estamos usando */}
    </div>
  );
}

export default App;

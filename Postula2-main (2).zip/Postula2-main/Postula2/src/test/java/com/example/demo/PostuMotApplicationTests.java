package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import co.edu.uco.postumot.initializer.PostuMotApplication;

@SpringBootTest(classes = PostuMotApplication.class)
class PostuMotApplicationTests {

	@Test
	void contextLoads() {
	}

}
package co.edu.uco.crosscutting.exceptions.enums;

public enum Layer {
	GENERAL, DATA, BUSINESSLOGIC, CONTROLLER, DTO, ENTITY, DOMAIN
}

-- Tabla 'city' con id como UUID
CREATE TABLE city (
    id UUID NOT NULL,
    nombre VARCHAR(60) NOT NULL,
    departamento_id UUID NOT NULL
);

ALTER TABLE city ADD CONSTRAINT city_pk PRIMARY KEY (id);

-- Tabla 'departamento' con id como UUID
CREATE TABLE departamento (
    id UUID NOT NULL,
    nombre VARCHAR(60) NOT NULL,
    pais_id UUID NOT NULL
);

ALTER TABLE departamento ADD CONSTRAINT departamento_pk PRIMARY KEY (id);

-- Tabla 'pais' con id como UUID
CREATE TABLE pais (
    id UUID NOT NULL,
    nombre VARCHAR(60) NOT NULL
);

ALTER TABLE pais ADD CONSTRAINT pais_pk PRIMARY KEY (id);

-- Tabla 'postulante' con id como UUID
CREATE TABLE postulante (
    id UUID NOT NULL,
    documento BIGINT NOT NULL,
    primernombre VARCHAR(60) NOT NULL,
    segundonombre VARCHAR(60),
    primerapellido VARCHAR(60) NOT NULL,
    segundoapellido VARCHAR(60),
    telefono BIGINT NOT NULL,
    correo VARCHAR(60),
    genero VARCHAR(20) NOT NULL,
    tipodocumento_id UUID NOT NULL,
    city_id UUID NOT NULL
);

ALTER TABLE postulante ADD CONSTRAINT postulante_pk PRIMARY KEY (id);

-- Tabla 'tipodocumento' con id como UUID
CREATE TABLE tipodocumento (
    id UUID NOT NULL,
    nombre VARCHAR(60) NOT NULL
);

ALTER TABLE tipodocumento ADD CONSTRAINT tipodocumento_pk PRIMARY KEY (id);

-- Foreign keys
ALTER TABLE city
    ADD CONSTRAINT city_departamento_fk FOREIGN KEY (departamento_id)
    REFERENCES departamento (id);

ALTER TABLE departamento
    ADD CONSTRAINT departamento_pais_fk FOREIGN KEY (pais_id)
    REFERENCES pais (id);

ALTER TABLE postulante
    ADD CONSTRAINT postulante_city_fk FOREIGN KEY (city_id)
    REFERENCES city (id);

ALTER TABLE postulante
    ADD CONSTRAINT postulante_tipodocumento_fk FOREIGN KEY (tipodocumento_id)
    REFERENCES tipodocumento (id);

